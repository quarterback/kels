#!/usr/bin/env python3
"""Transliterate canonical Metropolitan Nelôxi <-> Modern Anbur.

Modern Anbur is caseless, so reverse transliteration restores lowercase Latin.
Punctuation, whitespace, ASCII dozenal figures (0-9 D E), and nonletters pass through.
"""

from __future__ import annotations

import argparse
import sys
import unicodedata

LATIN_TO_ANBUR = {
    "a": "𐍐",
    "b": "𐍑",
    "d": "𐍓",
    "e": "𐍔",
    "f": "𐍫",
    "g": "𐍒",
    "h": "𐍬",
    "i": "𐍙",
    "j": "𐍵",
    "k": "𐍚",
    "l": "𐍛",
    "m": "𐍜",
    "n": "𐍝",
    "o": "𐍩",
    "p": "𐍟",
    "r": "𐍠",
    "s": "𐍡",
    "t": "𐍢",
    "u": "𐍣",
    "v": "𐍞",
    "x": "𐍥",
    "y": "𐍳",
    "ä": "𐍱",
    "ö": "𐍪",
    "ô": "𐍨",
    "ç": "𐍭",
    "ñ": "𐍝\u0300",  # NENOE + grave: palatal /ɲ/
    "ļ": "𐍛\u0300",  # LEI + grave: palatal /lʲ/
    "õ": "𐍯",
    # Scar / legacy letters
    "ž": "𐍕",
    "dž": "𐍖",
    "z": "𐍗",
    "w": "𐍮",
    "ü": "𐍧",
    "œ": "𐍰",
    "š": "𐍦",
}

LONG_VOWELS = {
    "ā": "a",
    "ē": "e",
    "ī": "i",
    "ō": "o",
    "ū": "u",
    "ǟ": "ä",
    "ȫ": "ö",
}

MACRON = "\u0304"
GRAVE = "\u0300"


def to_anbur(text: str, strict: bool = True) -> str:
    text = unicodedata.normalize("NFC", text)
    out: list[str] = []
    i = 0

    while i < len(text):
        # Canonical special geminate must be handled before ordinary l.
        if text[i:i + 3].lower() == "l·l":
            out.append("𐍛·𐍛")
            i += 3
            continue

        # Canonical scar digraph.
        if text[i:i + 2].lower() == "dž":
            out.append(LATIN_TO_ANBUR["dž"])
            i += 2
            continue

        ch = text[i]
        low = ch.lower()

        if low in LONG_VOWELS:
            base = LONG_VOWELS[low]
            out.append(LATIN_TO_ANBUR[base] + MACRON)
        elif low in LATIN_TO_ANBUR:
            out.append(LATIN_TO_ANBUR[low])
        elif ch.isalpha() and strict:
            raise ValueError(f"Unmapped alphabetic character at {i}: {ch!r}")
        else:
            out.append(ch)

        i += 1

    # Preserve decomposed combining marks exactly as specified.
    return "".join(out)


# Longest sequences first.
ANBUR_TO_LATIN = {
    "𐍛·𐍛": "l·l",
    "𐍝" + GRAVE: "ñ",
    "𐍛" + GRAVE: "ļ",
    "𐍐" + MACRON: "ā",
    "𐍔" + MACRON: "ē",
    "𐍙" + MACRON: "ī",
    "𐍩" + MACRON: "ō",
    "𐍣" + MACRON: "ū",
    "𐍱" + MACRON: "ǟ",
    "𐍪" + MACRON: "ȫ",
    "𐍐": "a",
    "𐍑": "b",
    "𐍓": "d",
    "𐍔": "e",
    "𐍫": "f",
    "𐍒": "g",
    "𐍬": "h",
    "𐍙": "i",
    "𐍵": "j",
    "𐍚": "k",
    "𐍛": "l",
    "𐍜": "m",
    "𐍝": "n",
    "𐍩": "o",
    "𐍟": "p",
    "𐍠": "r",
    "𐍡": "s",
    "𐍢": "t",
    "𐍣": "u",
    "𐍞": "v",
    "𐍥": "x",
    "𐍳": "y",
    "𐍱": "ä",
    "𐍪": "ö",
    "𐍨": "ô",
    "𐍭": "ç",
    "𐍯": "õ",
    "𐍕": "ž",
    "𐍖": "dž",
    "𐍗": "z",
    "𐍮": "w",
    "𐍧": "ü",
    "𐍰": "œ",
    "𐍦": "š",
}

REVERSE_KEYS = sorted(ANBUR_TO_LATIN, key=len, reverse=True)


def from_anbur(text: str, strict: bool = True) -> str:
    # Do not NFC-compose: sequence boundaries are part of the orthography.
    out: list[str] = []
    i = 0

    while i < len(text):
        for seq in REVERSE_KEYS:
            if text.startswith(seq, i):
                out.append(ANBUR_TO_LATIN[seq])
                i += len(seq)
                break
        else:
            ch = text[i]
            if (
                0x10350 <= ord(ch) <= 0x1037A
                and strict
            ):
                raise ValueError(
                    f"Unassigned Old Permic character at {i}: U+{ord(ch):04X}"
                )
            out.append(ch)
            i += 1

    return "".join(out)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--reverse",
        action="store_true",
        help="Modern Anbur -> lowercase canonical Latin",
    )
    parser.add_argument(
        "--no-strict",
        action="store_true",
        help="Pass unmapped alphabetic/Old Permic characters through",
    )
    parser.add_argument(
        "text",
        nargs="*",
        help="Text to transliterate; stdin is used when omitted",
    )
    args = parser.parse_args()

    source = " ".join(args.text) if args.text else sys.stdin.read()
    fn = from_anbur if args.reverse else to_anbur

    try:
        result = fn(source, strict=not args.no_strict)
    except ValueError as exc:
        print(f"anbur: {exc}", file=sys.stderr)
        return 2

    sys.stdout.write(result)
    if args.text:
        sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
